# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: local-startup.spec.ts >> first navigation 2 renders without optimizer invalidation
- Location: ../../../../foldkit/.maintainer/contributions/issue-1628-cold-vite-cache/reproduction/local-startup.spec.ts:5:3

# Error details

```
Error: V2 optimizer diagnostics

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   Object {
+     "data": "{\"type\":\"full-reload\",\"path\":\"*\"}",
+     "elapsedMs": 213.40479800000003,
+     "kind": "websocket-received",
+   },
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - generic [ref=f1e3]:
    - banner [ref=f1e4]:
      - heading "API Cache" [level=1] [ref=f1e5]
      - paragraph [ref=f1e6]: Query.define owns each fetch and its retained data. The parent decides when each Query should load or refresh.
    - generic [ref=f1e7]:
      - tablist "API cache sections" [ref=f1e8]:
        - tab "Posts" [selected] [ref=f1e9] [cursor=pointer]
        - tab "Stats" [ref=f1e10] [cursor=pointer]
      - tabpanel "Posts" [ref=f1e11]:
        - generic [ref=f1e13]:
          - generic [ref=f1e14]:
            - heading "Posts" [level=2] [ref=f1e15]
            - button "Refresh" [ref=f1e16] [cursor=pointer]
          - paragraph [ref=f1e17]: Open a post, then go back. The detail stays in the Query. Opening it again reads that entry and does not fetch.
          - list [ref=f1e19]:
            - listitem [ref=f1e20]:
              - button "The Model Is the Cache Why a single source of truth needs no query client." [ref=f1e21] [cursor=pointer]:
                - generic [ref=f1e22]:
                  - generic [ref=f1e23]: The Model Is the Cache
                  - generic [ref=f1e24]: Why a single source of truth needs no query client.
            - listitem [ref=f1e25]:
              - button "Stale-While-Revalidate, Explained Show the old data while the new data loads." [ref=f1e26] [cursor=pointer]:
                - generic [ref=f1e27]:
                  - generic [ref=f1e28]: Stale-While-Revalidate, Explained
                  - generic [ref=f1e29]: Show the old data while the new data loads.
            - listitem [ref=f1e30]:
              - button "Query Keys Are Just Names A Model field per query replaces stringly-typed keys." [ref=f1e31] [cursor=pointer]:
                - generic [ref=f1e32]:
                  - generic [ref=f1e33]: Query Keys Are Just Names
                  - generic [ref=f1e34]: A Model field per query replaces stringly-typed keys.
            - listitem [ref=f1e35]:
              - button "Refresh Is a Message Requesting newer data is a fact, not hidden framework policy." [ref=f1e36] [cursor=pointer]:
                - generic [ref=f1e37]:
                  - generic [ref=f1e38]: Refresh Is a Message
                  - generic [ref=f1e39]: Requesting newer data is a fact, not hidden framework policy.
            - listitem [ref=f1e40]:
              - button "This Post Is Unavailable Open it to see the Failure and Retry states." [ref=f1e41] [cursor=pointer]:
                - generic [ref=f1e42]:
                  - generic [ref=f1e43]: This Post Is Unavailable
                  - generic [ref=f1e44]: Open it to see the Failure and Retry states.
  - button "D E V" [ref=f1e45] [cursor=pointer]:
    - generic [ref=f1e46]:
      - generic [ref=f1e47]: D
      - generic [ref=f1e48]: E
      - generic [ref=f1e49]: V
```

# Test source

```ts
  1  | import { test, expect } from '/home/om/TAO/Tools/foldkit-worktrees/issue-1628-cold-vite-cache/node_modules/.pnpm/@playwright+test@1.63.0/node_modules/@playwright/test/index.mjs'
  2  | import { writeFile } from 'node:fs/promises'
  3  | 
  4  | for (const pageNumber of [1, 2, 3]) {
  5  |   test(`first navigation ${pageNumber} renders without optimizer invalidation`, async ({ page }, testInfo) => {
  6  |     const events = []
  7  |     const started = performance.now()
  8  |     const record = (kind, data) => events.push({ elapsedMs: performance.now() - started, kind, data })
  9  |     page.on('response', response => { if (response.status() >= 400) { record('http-error', { url: response.url(), status: response.status(), statusText: response.statusText() }) } })
  10 |     page.on('requestfailed', request => record('request-failed', { url: request.url(), failure: request.failure() }))
  11 |     page.on('pageerror', error => record('page-error', error.message))
  12 |     page.on('console', message => record('console', { type: message.type(), text: message.text() }))
  13 |     page.on('websocket', socket => {
  14 |       record('websocket-created', socket.url())
  15 |       socket.on('framereceived', frame => record('websocket-received', frame.payload))
  16 |       socket.on('framesent', frame => record('websocket-sent', frame.payload))
  17 |     })
  18 |     page.on('framenavigated', frame => { if (frame === page.mainFrame()) { record('navigation', frame.url()) } })
  19 |     try {
  20 |       await page.goto('/')
  21 |       const slug = process.env.EXAMPLE_SLUG ?? 'api-cache-query'
  22 |       if (slug === 'counter') {
  23 |         await page.getByRole('button', { name: '+', exact: true }).click()
  24 |         await expect(page).toHaveTitle(/Counter: 1/)
  25 |       } else if (slug === 'ui-showcase') {
  26 |         await page.getByRole('link', { name: 'Button', exact: true }).first().click()
  27 |         await expect(page).toHaveURL(/\/button$/)
  28 |       } else {
  29 |         await expect(page.getByRole('button', { name: 'The Model Is the Cache' })).toBeVisible()
  30 |       }
  31 |       await expect(page.locator('#foldkit-devtools')).toBeAttached()
  32 |       record('content-passed', slug)
  33 |       const failures = events.filter(event => event.kind === 'page-error' || (event.kind === 'http-error' && (event.data.statusText.includes('Outdated Optimize Dep') || event.data.url.includes('/.vite/deps/'))) || (event.kind === 'request-failed' && event.data.url.includes('/.vite/deps/')) || (event.kind === 'websocket-received' && String(event.data).includes('full-reload')))
> 34 |       expect(failures, 'V2 optimizer diagnostics').toEqual([])
     |                                                    ^ Error: V2 optimizer diagnostics
  35 |     } finally {
  36 |       record('body', await page.locator('body').innerHTML().catch(error => String(error)))
  37 |       await writeFile(testInfo.outputPath('events.json'), JSON.stringify(events, null, 2))
  38 |     }
  39 |   })
  40 | }
  41 | 
```