# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: local-startup.spec.ts >> first navigation 3 renders without optimizer invalidation
- Location: ../../../../foldkit/.maintainer/contributions/issue-1628-cold-vite-cache/reproduction/local-startup.spec.ts:5:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: 'The Model Is the Cache' })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('button', { name: 'The Model Is the Cache' }) with timeout 15000ms
  - waiting for getByRole('button', { name: 'The Model Is the Cache' })

```

# Test source

```ts
  1  | import { test, expect } from '/home/om/TAO/Tools/foldkit-worktrees/issue-1628-cold-vite-cache/node_modules/.pnpm/@playwright+test@1.63.0/node_modules/@playwright/test/index.mjs'
  2  | import { writeFile } from 'node:fs/promises'
  3  | 
  4  | for (const pageNumber of [1, 2, 3]) {
  5  |   test(`first navigation ${pageNumber} renders without optimizer invalidation`, async ({ page }, testInfo) => {
  6  |     const events = []
  7  |     const started = performance.now()
  8  |     const record = (kind, data) => events.push({ elapsedMs: performance.now() - started, kind, data })
  9  |     page.on('response', response => { if (response.status() >= 400) { record('http-error', { url: response.url(), status: response.status(), statusText: response.statusText() }) } })
  10 |     page.on('requestfailed', request => record('request-failed', { url: request.url(), failure: request.failure() }))
  11 |     page.on('pageerror', error => record('page-error', error.message))
  12 |     page.on('console', message => record('console', { type: message.type(), text: message.text() }))
  13 |     page.on('websocket', socket => {
  14 |       record('websocket-created', socket.url())
  15 |       socket.on('framereceived', frame => record('websocket-received', frame.payload))
  16 |       socket.on('framesent', frame => record('websocket-sent', frame.payload))
  17 |     })
  18 |     page.on('framenavigated', frame => { if (frame === page.mainFrame()) { record('navigation', frame.url()) } })
  19 |     try {
  20 |       await page.goto('/')
  21 |       const slug = process.env.EXAMPLE_SLUG ?? 'api-cache-query'
  22 |       if (slug === 'counter') {
  23 |         await page.getByRole('button', { name: '+', exact: true }).click()
  24 |         await expect(page).toHaveTitle(/Counter: 1/)
  25 |       } else if (slug === 'ui-showcase') {
  26 |         await page.getByRole('link', { name: 'Button', exact: true }).first().click()
  27 |         await expect(page).toHaveURL(/\/button$/)
  28 |       } else {
> 29 |         await expect(page.getByRole('button', { name: 'The Model Is the Cache' })).toBeVisible()
     |                                                                                    ^ Error: expect(locator).toBeVisible() failed
  30 |       }
  31 |       await expect(page.locator('#foldkit-devtools')).toBeAttached()
  32 |       record('content-passed', slug)
  33 |       const failures = events.filter(event => event.kind === 'page-error' || (event.kind === 'http-error' && (event.data.statusText.includes('Outdated Optimize Dep') || event.data.url.includes('/.vite/deps/'))) || (event.kind === 'request-failed' && event.data.url.includes('/.vite/deps/')) || (event.kind === 'websocket-received' && String(event.data).includes('full-reload')))
  34 |       expect(failures, 'V2 optimizer diagnostics').toEqual([])
  35 |     } finally {
  36 |       record('body', await page.locator('body').innerHTML().catch(error => String(error)))
  37 |       await writeFile(testInfo.outputPath('events.json'), JSON.stringify(events, null, 2))
  38 |     }
  39 |   })
  40 | }
  41 | 
```