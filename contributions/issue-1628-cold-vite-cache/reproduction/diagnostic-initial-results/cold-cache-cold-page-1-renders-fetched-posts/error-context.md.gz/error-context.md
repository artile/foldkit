# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: cold-cache.spec.ts >> cold page 1 renders fetched posts
- Location: ../../../../foldkit/.maintainer/contributions/issue-1628-cold-vite-cache/reproduction/cold-cache.spec.ts:5:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: 'The Model Is the Cache', exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('button', { name: 'The Model Is the Cache', exact: true }) with timeout 15000ms
  - waiting for getByRole('button', { name: 'The Model Is the Cache', exact: true })

```

# Test source

```ts
  1  | import { test, expect } from '/home/om/TAO/Tools/foldkit-worktrees/issue-1628-cold-vite-cache/node_modules/.pnpm/@playwright+test@1.63.0/node_modules/@playwright/test/index.mjs'
  2  | import { writeFile } from 'node:fs/promises'
  3  | 
  4  | for (const pageNumber of [1, 2, 3]) {
  5  |   test(`cold page ${pageNumber} renders fetched posts`, async ({ page }, testInfo) => {
  6  |     const events = []
  7  |     const startedAt = performance.now()
  8  |     const record = (kind, data) => events.push({ elapsedMs: performance.now() - startedAt, kind, data })
  9  |     page.on('response', response => {
  10 |       if (response.status() >= 400) {
  11 |         record('http-error', { url: response.url(), status: response.status(), statusText: response.statusText() })
  12 |       }
  13 |     })
  14 |     page.on('requestfailed', request => record('request-failed', { url: request.url(), failure: request.failure() }))
  15 |     page.on('pageerror', error => record('page-error', error.message))
  16 |     page.on('console', message => record('console', { type: message.type(), text: message.text() }))
  17 |     page.on('websocket', socket => {
  18 |       record('websocket-created', socket.url())
  19 |       socket.on('framereceived', frame => record('websocket-received', frame.payload))
  20 |       socket.on('framesent', frame => record('websocket-sent', frame.payload))
  21 |     })
  22 |     page.on('framenavigated', frame => {
  23 |       if (frame === page.mainFrame()) { record('navigation', frame.url()) }
  24 |     })
  25 |     try {
  26 |       await page.goto('/')
> 27 |       await expect(page.getByRole('button', { name: 'The Model Is the Cache', exact: true })).toBeVisible({ timeout: 15000 })
     |                                                                                               ^ Error: expect(locator).toBeVisible() failed
  28 |       await expect(page.locator('[data-foldkit-app]')).toHaveCount(1)
  29 |     } finally {
  30 |       record('body', await page.locator('body').innerHTML().catch(error => String(error)))
  31 |       await writeFile(testInfo.outputPath('events.json'), JSON.stringify(events, null, 2))
  32 |     }
  33 |   })
  34 | }
  35 | 
```